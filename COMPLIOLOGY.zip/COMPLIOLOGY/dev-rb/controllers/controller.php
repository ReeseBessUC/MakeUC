<?php
include('compliology.class.php');
include('shortcodes.php');
?>