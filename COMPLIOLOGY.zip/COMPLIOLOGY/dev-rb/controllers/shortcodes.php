<?php
class devShortcodes {
    private $shortcodes = array(
        'pdf_files' => 'fs_pdf_files',
        'invite_user_link' => 'fs_invite_user_link',
        'org_sign_up' => 'fs_org_sign_up',
        'cpt_org' => 'fs_cpt_org',
        'org_roles' => 'fs_org_roles',
        'cpt_staff' => 'fs_cpt_staff',
        'cpt_videos' => 'fs_cpt_videos',
        'questions_list' => 'fs_questions_list',
        'video_quiz' => 'fs_video_quiz'
    );
    
    function __construct() {
        
        foreach ($this->shortcodes as $shortcode => $callback)
        {
            add_shortcode($shortcode, array($this, $callback));
        }
    }
    
    function fs_pdf_files() {
        return get_template_part('template_parts/pdf_files');
    }

    
    function fs_invite_user_link() {
        return get_template_part('template_parts/invite_user_link');
    }

    function fs_org_sign_up() {
        return get_template_part('template_parts/org_sign_up');
    }

    function fs_cpt_org() {
        return get_template_part('template_parts/cpt_org_list');
    }

    function fs_org_roles() {
        return get_template_part('template_parts/cpt_org_roles');
    }

    function fs_cpt_staff() {
        return get_template_part('template_parts/cpt_staff');
    }

    function fs_cpt_videos() {
        return get_template_part('template_parts/cpt_videos');
    }

    function fs_questions_list() {
        return get_template_part('template_parts/questions_list');
    }

    function fs_video_quiz() {
        return get_template_part('template_parts/video_quiz');
    }

}

new devShortcodes();