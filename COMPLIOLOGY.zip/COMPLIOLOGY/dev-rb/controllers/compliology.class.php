<?php
/*
 * Following Class holds general functions;
 */
//use Ramsey\Uuid\Uuid;

class Compliology {
    
    public $child_theme             = "dev-rb";
    
    function __construct() {
        
        global $wpdb;
        
        add_action('wp_enqueue_scripts', [$this, 'fs_load_scripts']);
        add_action( 'template_redirect',  [$this, 'fs_template_redirect'] );

        add_filter( 'login_redirect', [$this, 'redirect_sub_to_home'], 10, 3 );
        add_action('wp_head',[$this, 'fs_hide_admin_wpse']);

        add_action('acf/save_post', [$this, 'fs_acf_save_post']);
        
        add_action('wp_ajax_get_competitions', [$this, 'fs_get_competitions'] );
        add_action('wp_ajax_nopriv_get_competitions', [$this, 'fs_get_competitions'] );
        
    }

    function redirect_sub_to_home($redirect_to, $request, $user) {
        
        
        if ( isset($user->roles) && is_array( $user->roles ) ) {
            if ( !in_array( 'administrator', $user->roles ) ) {
                //return home_url( );
                return get_permalink( 75 );
            }   
          }
          return $redirect_to;
          
    }
    
    function fs_hide_admin_wpse() {
        $current_user = wp_get_current_user();
        //if (current_user_can('subscriber')) {
        if ( !in_array( 'administrator', $current_user->roles ) ) {
            add_filter('show_admin_bar','__return_false');
        }
    }

    function fs_load_scripts(){
        
        wp_register_style( 'datatable_style', 'https://cdn.datatables.net/v/dt/dt-1.12.1/rr-1.2.8/datatables.min.css' );
        wp_register_style( 'bootstrapgrid_style', 'https://cdn.jsdelivr.net/npm/bootstrap-v4-grid-only@1.0.0/dist/bootstrap-grid.min.css' );
        //wp_enqueue_style( 'fs_style', home_url() . '/wp-content/themes/fullstackology/css/fs_style.css?t='.time() );
        wp_enqueue_style( 'toastr_style', '//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css' );
        
        
        
        wp_register_script( 'datatable_script', 'https://cdn.datatables.net/v/dt/dt-1.12.1/rr-1.2.8/datatables.min.js', array('jquery') );
        wp_enqueue_script( 'toastr_script', '//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js', array('jquery') );
        
        wp_register_script( 'fontawesome_5', 'https://kit.fontawesome.com/72a79b2532.js' );
    }
    
    function fs_template_redirect() {

        # Organization User Signup
        if (isset($_POST['frmOrgSignup']))
        {

            $user_id = wp_insert_user([
                'user_pass' => $_POST['password'],
                'user_login' => $_POST['email'],
                'user_email' => $_POST['email'],
                'role' => 'org_user'
            ]);

            update_user_meta($user_id, "service_provider_id", $_POST['service_provider_id']);

            global $post;
            wp_redirect( add_query_arg([
                'registered' => '1'
            ], get_permalink($post->ID)) );
            exit;
        }

        # Questions's Answers submission;
        if (isset($_POST['sbtSubmitAnswers']))
        {
            foreach ($_POST['answers'] as $qId => $answer)
            {
                $answer_id = wp_insert_post([
                    'post_type' => 'org-answer',
                    'post_status' => 'publish',
                    'post_title' => $qId . "-" . get_current_user_id() . "-" . $answer
                ]);

                update_post_meta($answer_id, "question", get_the_title($qId));
                update_post_meta($answer_id, "question_id", $qId);
                update_post_meta($answer_id, "answer", $answer);
                update_post_meta($answer_id, "datetime_of_answer", gmdate("Y-m-d H:i:s"));

                $organizations = $this->get_organizations( true );
                update_post_meta($answer_id, "organization_fk", $organizations[0]->ID);
            }

            global $post;
            wp_redirect( add_query_arg(['submitted'=>'1'], get_permalink($post->ID)) );
            exit;
        }

        # Send Training link;
        if (isset($_POST['sbtSendVideoLink']))
        {
            global $post, $Compliology;
            $organization = $Compliology->get_organizations( true );
    
            # Get staff members from this organization;
            $staff = $Compliology->get_cpt_staff( $organization[0]->ID );

            foreach ($staff as $objStaff)
            {
                $email = get_post_meta($objStaff->ID, "email", true);

                $videoQuizLink = add_query_arg([
                    'video' => $_POST['video_id'],
                    'person' => $objStaff->ID
                ], get_permalink(336));

                $subject = "Training Video Page";
                $body = "Hi {$objStaff->post_title},<br><br>";
                $body .= "Go to following link, see the video and do the quiz.<br>";
                $body .= '<a href="'.$videoQuizLink.'">Take the Quiz</a>';

                $headers = array('Content-Type: text/html; charset=UTF-8');
                $sent = wp_mail($email, $subject, $body, $headers);

                if ($sent)
                {
                    $post_id = wp_insert_post([
                        'post_type' => 'org-training',
                        'post_status' => 'publish',
                        'post_title' => "Video:" . $_POST['video_id'] . " - Staff:" . $objStaff->ID
                    ]);
                    if ($post_id)
                    {
                        update_post_meta($post_id, "org_staff_fk", $objStaff->ID);
                        update_post_meta($post_id, "ftc_video_fk", $_POST['video_id']);
                        update_post_meta($post_id, "datetime_sent", gmdate("Y-m-d H:i:s"));
                        update_post_meta($post_id, "quiz_results", "na");
                    }
                }

                # Phishing mail;
                $phishing_content = [
                    "Free Money", "Free iPad", "Free Cash"
                ];
                $index = rand(0,3);
                wp_mail( $email, $phishing_content[$index], $phishing_content[$index] );

            }
            wp_redirect( add_query_arg(['sent'=>'1'], get_permalink($post->ID)) );
            exit;
        }

        # Video quiz answers submitted;
        if (isset($_POST['sbtVideoQuizSubmit']))
        {
            $status = "pass";

            $answer1 = trim($_POST['answer1']);
            $answer2 = trim($_POST['answer2']);
            $answer3 = trim($_POST['answer3']);

            $correct_answer1 = trim($_POST['correct_answer1']);
            $correct_answer2 = trim($_POST['correct_answer2']);
            $correct_answer3 = trim($_POST['correct_answer3']);

            if ($answer1 != $correct_answer1) $status = "fail";
            if ($answer2 != $correct_answer2) $status = "fail";
            if ($answer3 != $correct_answer3) $status = "fail";

            $video_id = $_GET['video'];
            $person = $_GET['person'];

            $objPost = get_posts([
                'post_type' => 'org-training',
                'meta_query' => array(
                    array(
                        'key'       => 'org_staff_fk',
                        'value'     => $person,
                    ),
                    array(
                        'key'       => 'ftc_video_fk',
                        'value'     => $video_id
                    )
                )
            ]);

            global $post;

            if ($objPost)
            {
                update_post_meta($objPost[0]->ID, "quiz_results", $status);
                wp_redirect( add_query_arg([
                    'submitted' => "1",
                    'video' => $video_id,
                    'person' => $person
                ], get_permalink($post->ID)) );
            }
            else
            {
                wp_redirect( add_query_arg([
                    'submitted' => "0",
                    'video' => $video_id,
                    'person' => $person
                ], get_permalink($post->ID)) );
            }
            
            exit;
        }
        
        /* All ACF form submissions will be handled here */
        if (
                isset($_POST['frm_add_org']) || 
                isset($_POST['frm_add_role']) || 
                isset($_POST['frm_add_staff']) || 
                isset($_POST['frm_add_video']) || 
                isset($_POST['frm_add_staff'])
           ) {
            # process form;
            ob_start();
            //acf_form_head();
        }
    }

    function fs_acf_save_post($post_id) {
        update_post_meta($post_id, "_user_id", get_current_user_id());
    }
    
    function get_organizations($for_logged_in = false) {

        $args = [
            'post_type' => 'organization',
            'post_status' => 'publish',
            'numberposts' => "-1"
        ];

        if ($for_logged_in)
        {
            $args['meta_key'] = "linked_user_id";
            $args['meta_value'] = get_current_user_id();
        }

        $posts = get_posts( $args );

        return $posts;
    }

    function get_org_roles() {
        $posts = get_posts([
            'post_type' => 'org-role',
            'post_status' => 'publish',
            'numberposts' => "-1"
        ]);

        return $posts;
    }

    function get_cpt_staff( $organization_fk = '' ) {

        $args = [
            'post_type' => 'org-staff',
            'post_status' => 'publish',
            'numberposts' => "-1"
        ];

        if (!empty($organization_fk))
        {
            $args['meta_key'] = "organization_fk";
            $args['meta_value'] = $organization_fk;
            $args['meta_compare'] = "LIKE";
        }

        $posts = get_posts( $args );

        return $posts;
    }

    function get_cpt_videos() {
        $posts = get_posts([
            'post_type' => 'ftc-video',
            'post_status' => 'publish',
            'numberposts' => "-1"
        ]);

        return $posts;
    }

    function get_all_questions() {
        $posts = get_posts([
            'post_type' => 'question',
            'post_status' => 'publish',
            'numberposts' => "-1"
        ]);

        return $posts;
    }
}

global $Compliology;
$Compliology = new Compliology();