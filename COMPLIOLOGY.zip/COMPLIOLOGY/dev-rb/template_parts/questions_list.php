<?php
global $Compliology;
$questions = $Compliology->get_all_questions();

if (@$_GET['submitted'])
{
    ?>
    <script>
        jQuery(document).ready(function(){
            toastr.success('Answers submitted.', 'Success', {timeOut: 5000})
        });
    </script>
    <?php
}

?>

<form action="" method="post">


<table border="0" class="noborder tblquestions">
<?php
if ($questions)
{
    $organizations = $Compliology->get_organizations( true );

    foreach ($questions as $question)
    {
        $answerSelected = "";

        $objPost = get_posts([
            'post_type' => 'org-answer',
            'meta_query' => array(
                array(
                    'key'       => 'question_id',
                    'value'     => $question->ID,
                ),
                array(
                    'key'       => 'organization_fk',
                    'value'     => $organizations[0]->ID
                )
            )
        ]);

        if ($objPost)
        {
            $answerSelected = get_post_meta($objPost[0]->ID, "answer", true);
        }

        ?>
        <tr style="border-bottom: 1px solid #000;">
            <td><?php echo $question->post_title; ?></td>
            <td>
                <select name="answers[<?php echo $question->ID ?>]">
                    <option value=""></option>
                    <option value="yes" <?php if ($answerSelected === "yes") echo "selected"; ?> >Yes</option>
                    <option value="no" <?php if ($answerSelected === "no") echo "selected"; ?> >No</option>
                    <option value="idk" <?php if ($answerSelected === "idk") echo "selected"; ?> >Don't Know</option>
                    <option value="na" <?php if ($answerSelected === "na") echo "selected"; ?> >Not Available</option>
                    <option value="itw" <?php if ($answerSelected === "itw") echo "selected"; ?> >In The Works</option>
                </select>
                
            </td>
        </tr>
        <?php
    }
    ?>
    
    <?php
}
?>
</table>

<div align="center">
    <input type="submit" value="Submit Answers" name="sbtSubmitAnswers" />
</div>

</form>