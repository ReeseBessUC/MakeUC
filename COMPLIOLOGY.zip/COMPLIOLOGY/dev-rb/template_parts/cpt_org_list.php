<?php

$view = @$_GET['view'];

if ($view === "add")
{
    get_template_part('template_parts/org_list_add');
}
else
{
    global $post;
    $addLink = add_query_arg(['view'=>'add'], get_permalink($post->ID));

    if (@$_GET['added'])
    {
        ?>
        <script>
            jQuery(document).ready(function(){
                toastr.success('Organization added.', 'Success', {timeOut: 5000})
            });
        </script>
        <?php
    }

    if (@$_GET['updated'])
    {
        ?>
        <script>
            jQuery(document).ready(function(){
                toastr.success('Organization updated.', 'Success', {timeOut: 5000})
            });
        </script>
        <?php
    }


    ?>
    <a id="btnAddOrg" class="button button-primary" href="<?php echo $addLink; ?>">Add Org</a>
    <br><br>

    <?php

    wp_enqueue_style( 'datatable_style' );
    wp_enqueue_script( 'datatable_script' );

    global $Compliology, $post;

    $organizations = $Compliology->get_organizations( true );

    ?>
    <table class="wp-list-table widefat fixed striped table-view-list posts" id="tbl_announcements">
        <thead>
            <tr>
                <th width="90">S.No</th>
                <th>Name</th>
                <th width=90></th>
                <th width="90"></th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (count($organizations))
            {
                $sno = 1;
                foreach ($organizations as $organization)
                {   
                    $editLink = add_query_arg(['view'=>'add','aid'=>$organization->ID], get_permalink($post->ID));
                    $linked_user_id = get_post_meta($organization->ID, "linked_user_id", true);
                    ?>
                    <tr data-pid="<?php echo $organization->ID; ?>">
                        <td><?php echo $sno++; ?></td>
                        <td><?php echo get_field("name", $organization->ID); ?></td>
                        <td>
                            <a target="_blank" href="https://app.compliology.tech/wp-content/uploads/WISP_Acme-Labs_001.pdf">Get WISP</a> 
                        </td>
                        <td>
                            <a  href="<?php echo $editLink; ?>">Edit</a> 
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>
        </tbody>
    </table>
    <script>
        jQuery(document).ready(function(){
            var table = jQuery('#tbl_announcements').DataTable();
        });
    </script>
    <style>
        <?php if (count($organizations)) { ?>
            #btnAddOrg { display:none;  }
        <?php } ?>
    </style>
    <?php

}