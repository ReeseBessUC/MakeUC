<?php

if (@$_GET['registered'])
{
    ?>
    <script>
        jQuery(document).ready(function(){
            toastr.success('Registration successfull.', 'Success', {timeOut: 5000});
            window.location = "wp-login.php";
        });
    </script>
    <?php
}

?>

<div style="width: 300px; margin:50px auto;">

<form action="" method="post">

<label>Email:</label>
<br>
<input type="email" name="email" />

<br><br>

<label>Password:</label>
<br>
<input type="password" name="password" />

<br><br>

<input type="submit" name="Sign Up" class="button button-primary" />

<input type="hidden" name="frmOrgSignup" vlaue="1" />
<input type="hidden" name="service_provider_id" value="2<?php //echo get_current_user_id(); ?>" />
</form>

</div>