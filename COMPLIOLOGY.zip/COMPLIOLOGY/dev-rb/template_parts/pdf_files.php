<?php
wp_enqueue_style( 'datatable_style' );
wp_enqueue_script( 'datatable_script' );
wp_enqueue_script( 'datatable_natural' );

?>
<div class="wrap">

<h1>Announcements</h1>

<?php
global $ia;

if (@$_GET['aid'] && @$_GET['action'] == "delete")
{
    $ia->delete_announcement($_GET['aid']);
    ?>
        <div class="notice notice-success is-dismissible">
            <p>Announcement deleted successfully.</p>
        </div>
    <?php
}

if (@$_GET['action'] == "added")
{
    ?>
        <div class="notice notice-success is-dismissible">
            <p>Announcement added successfully.</p>
        </div>
    <?php
}

if (@$_GET['action'] == "updated")
{
    ?>
        <div class="notice notice-success is-dismissible">
            <p>Announcement updated successfully.</p>
        </div>
    <?php
}



$announcements = $ia->announcements();
?>

<table class="wp-list-table widefat fixed striped table-view-list posts" id="tbl_announcements">
    <thead>
        <tr>
            <th>S.No</th>
            <th>Title</th>
            <th>Status</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (count($announcements))
        {
            $sno = 1;
            foreach ($announcements as $announcement)
            {   
                ?>
        <tr data-pid="<?php echo $announcement->post_id; ?>">
            <td><?php echo $sno++; ?></td>
            <td><?php echo $announcement->title; ?></td>
            <td><?php echo ($announcement->announcement_status) ? "Enabled" : "Disabled"; ?></td>
            <td><?php echo wp_date("Y-m-d H:i:s", strtotime($announcement->start_date)); ?></td>
            <td><?php echo wp_date("Y-m-d H:i:s", strtotime($announcement->end_date)); ?></td>
            <td>
                <a class="button button-primary" href="admin.php?page=add-announcement&aid=<?php echo $announcement->post_id; ?>&action=edit">Edit</a> 
                <a class="button button-danger" onclick="javascript: return confirm('Are you sure to delete?');" href="admin.php?page=ia-announcements&aid=<?php echo $announcement->post_id; ?>&action=delete">Delete</a>
            </td>
        </tr>
                <?php
            }
        }
        ?>
    </tbody>
</table>
<div id="result"></div>
<style>
#tbl_announcements_length select {
	padding: 2px 10px;
}
.button.button-danger {
	background: red;
	color: white;
	border-color: red;
}
</style>
<script>
jQuery(document).ready(function(){
    
    
    
    var table = jQuery('#tbl_announcements').DataTable({
        rowReorder: true,
        initComplete: function () {
            this.api()
                .columns()
                .every(function (index) {
                    if (index == 2)
                    {
                        var column = this;
                    var select = jQuery('<select><option value="">All</option></select>')
                        .appendTo(jQuery(column.header()).empty())
                        .on('change', function () {
                            var val = jQuery.fn.dataTable.util.escapeRegex(jQuery(this).val());
 
                            column.search(val ? '^' + val + '$' : '', true, false).draw();
                        });
 
                    column
                        .data()
                        .unique()
                        .sort()
                        .each(function (d, j) {
                            select.append('<option value="' + d + '">' + d + '</option>');
                        });
                    }
                });
        },
    });
    
    table.on( 'row-reorder', function ( e, diff, edit ) {
        var result = 'Reorder started on row: '+edit.triggerRow.data()[1]+'<br>';
 
        for ( var i=0, ien=diff.length ; i<ien ; i++ ) {
            
            console.log(diff[i].node.dataset.pid);
            
            jQuery.ajax({
                type: 'POST',
                url: "<?php echo admin_url('admin-ajax.php'); ?>" ,
                data: {
                    action: 'fs_save_announcement_sorting',
                    pid: diff[i].node.dataset.pid,
                    order: diff[i].newData
                }, 
                success: function(msg){
                    console.log(msg);
                }
            });
            
            var rowData = table.row( diff[i].node ).data();
 
            result += rowData[1]+' updated to be in position '+
                diff[i].newData+' (was '+diff[i].oldData+')<br>';
        }
 
        //jQuery('#result').html( 'Event result:<br>'+result );
    } );
});
</script>
</div>
