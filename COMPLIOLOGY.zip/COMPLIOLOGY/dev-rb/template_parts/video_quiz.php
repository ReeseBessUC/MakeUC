<?php

if (isset($_GET['submitted']) && $_GET['submitted'] === "1")
{
    ?>
    <script>
        jQuery(document).ready(function(){
            toastr.success('Quiz submitted successfully.', 'Success', {timeOut: 5000})
        });
    </script>
    <?php
}
if (isset($_GET['submitted']) && $_GET['submitted'] === "0")
{
    ?>
    <script>
        jQuery(document).ready(function(){
            toastr.error('Something went wrong.', 'Error', {timeOut: 5000})
        });
    </script>
    <?php
}

$video_id = $_GET['video'];

$objVideo = get_post($video_id);

//p_r($objVideo);

$url = get_post_meta($objVideo->ID, "url", true);
$urlParts = explode("/", $url);
$embedID = $urlParts[count($urlParts)-1];

?>

<h2><?php echo $objVideo->post_title ?></h2>

<br>

<iframe width="560" height="315" 
src="https://www.youtube.com/embed/<?php echo $embedID ?>" 
title="<?php echo $objVideo->post_title ?>" 
frameborder="0" 
allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
allowfullscreen></iframe>

<form action="" method="post">

<hr>

<br>

<b>Take a Quiz</b>

<br><br>

<?php
$question1 = get_post_meta($objVideo->ID, "question_1", true);
$question2 = get_post_meta($objVideo->ID, "question_2", true);
$question3 = get_post_meta($objVideo->ID, "question_3", true);

$options1 = get_post_meta($objVideo->ID, "options_1", true);
$options2 = get_post_meta($objVideo->ID, "options_2", true);
$options3 = get_post_meta($objVideo->ID, "options_3", true);

$correct_answer_1 = get_post_meta($objVideo->ID, "correct_answer_1", true);
$correct_answer_2 = get_post_meta($objVideo->ID, "correct_answer_2", true);
$correct_answer_3 = get_post_meta($objVideo->ID, "correct_answer_3", true);

$options1_array = explode("\n", $options1);
$options2_array = explode("\n", $options2);
$options3_array = explode("\n", $options3);

?>

<?php echo $question1 ?>
<br>
<?php

foreach ($options1_array as $option)
{
    ?>
    <input type="radio" name="answer1" value="<?php echo $option ?>" /> <?php echo $option ?><br>
    <?php
}

?>
<input type="hidden" name="correct_answer1" value="<?php echo $correct_answer_1 ?>" />
<br>

<?php echo $question2 ?>
<br>
<?php

foreach ($options2_array as $option)
{
    ?>
    <input type="radio" name="answer2" value="<?php echo $option ?>" /> <?php echo $option ?><br>
    <?php
}

?>
<input type="hidden" name="correct_answer2" value="<?php echo $correct_answer_2 ?>" />
<br>

<?php echo $question3 ?>
<br>
<?php

foreach ($options3_array as $option)
{
    ?>
    <input type="radio" name="answer3" value="<?php echo $option ?>" /> <?php echo $option ?><br>
    <?php
}

?>
<input type="hidden" name="correct_answer3" value="<?php echo $correct_answer_3 ?>" />
<br>
<input type="submit" value="Submit Quiz" class="button button-primary" name="sbtVideoQuizSubmit" />
</form>
<style>
.site-header-primary-section-right {
    display: none;
}
</style>