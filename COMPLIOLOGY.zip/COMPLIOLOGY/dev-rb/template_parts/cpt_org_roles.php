<?php

$view = @$_GET['view'];

if ($view === "add")
{
    get_template_part('template_parts/org_role_add');
}
else
{
    global $post;
    $addLink = add_query_arg(['view'=>'add'], get_permalink($post->ID));

    if (@$_GET['added'])
    {
        ?>
        <script>
            jQuery(document).ready(function(){
                toastr.success('Role added.', 'Success', {timeOut: 5000})
            });
        </script>
        <?php
    }

    if (@$_GET['updated'])
    {
        ?>
        <script>
            jQuery(document).ready(function(){
                toastr.success('Role updated.', 'Success', {timeOut: 5000})
            });
        </script>
        <?php
    }


    ?>
    <a class="button button-primary" href="<?php echo $addLink; ?>">Add Role</a>
    <br><br>

    <?php

    wp_enqueue_style( 'datatable_style' );
    wp_enqueue_script( 'datatable_script' );

    global $Compliology, $post;

    $organizations = $Compliology->get_org_roles();

    ?>
    <table class="wp-list-table widefat fixed striped table-view-list posts" id="tbl_announcements">
        <thead>
            <tr>
                <th width="90">S.No</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Role</th>
                <th width="90"></th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (count($organizations))
            {
                $sno = 1;
                foreach ($organizations as $organization)
                {   
                    $editLink = add_query_arg(['view'=>'add','aid'=>$organization->ID], get_permalink($post->ID));
                    ?>
                    <tr data-pid="<?php echo $organization->ID; ?>">
                        <td><?php echo $sno++; ?></td>
                        <td><?php echo get_field("name_first", $organization->ID); ?></td>
                        <td><?php echo get_field("name_last", $organization->ID); ?></td>
                        <td><?php 
                            $roles = get_field("role_fk", $organization->ID); 
                            if ($roles)
                            {
                                echo $roles[0]->post_title;
                            }
                            ?>
                        </td>
                        <td>
                            <a  href="<?php echo $editLink; ?>">Edit</a> 
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>
        </tbody>
    </table>
    <script>
        jQuery(document).ready(function(){
            var table = jQuery('#tbl_announcements').DataTable();
        });
    </script>
    <?php

}