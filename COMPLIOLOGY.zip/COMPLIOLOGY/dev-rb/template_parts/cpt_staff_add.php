<div class="wrap">

<h1>Add Staff</h1>

<?php  

global $post;

acf_form_head();


$settings = array(
    'id' => 'add_staff',
    //'post_id' => 'new_post',
    'new_post' => array(
        'post_type' => 'org-staff',
        'post_status' => 'publish'
    ),
    'field_groups' => array('group_65471522a321b'),
    'form' => true,
    'post_title' => true,
    'html_after_fields' => '<input type="hidden" name="frm_add_staff" value="1">'
);
                
if (empty(@$_GET['aid']))
{
    $settings['post_id'] = 'new_post';
    $settings['submit_value'] = "Add Staff";
    $settings['return'] = add_query_arg(['added'=>'1'], get_permalink($post->ID));
}
else
{
    $settings['post_id'] = $_GET['aid'];
    $settings['submit_value'] = "Update Staff";
    $settings['return'] = add_query_arg(['updated'=>'1'], get_permalink($post->ID));
}
                
acf_form( $settings );
?>

</div>