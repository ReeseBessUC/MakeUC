<?php

$view = @$_GET['view'];

if ($view === "add")
{
    get_template_part('template_parts/cpt_video_add');
}
else
{
    global $post, $Compliology;

    if (@$_GET['sent'])
    {
        ?>
        <script>
            jQuery(document).ready(function(){
                toastr.success('Training email sent.', 'Success', {timeOut: 5000})
            });
        </script>
        <?php
    }


    $videos = $Compliology->get_cpt_videos();
    ?>
    <form action="" method="post">
    Choose Video to send: 
    <select name="video_id">
        <option value=""></option>
        <?php foreach ($videos as $video) { ?>
            <option value="<?php echo $video->ID; ?>"><?php echo $video->post_title; ?></option>
        <?php } ?>
    </select>
    
    <input type="submit" name="sbtSendVideoLink" value="Send Training Link" />
    </form>
    <br>
    <hr>

    <br>

    <br>

    <?php

    wp_enqueue_style( 'datatable_style' );
    wp_enqueue_script( 'datatable_script' );

    global $Compliology, $post;

    $answers = get_posts([
        'post_type' => 'org-training',
        'post_status' => 'publish',
        'numberposts' => "-1"
    ]);

    ?>
    <table class="wp-list-table widefat fixed striped table-view-list posts" id="tbl_announcements">
        <thead>
            <tr>
                <th width="90">S.No</th>
                <th>Video</th>
                <th>Staff</th>
                <th width="90">Result</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (count($answers))
            {
                $sno = 1;
                foreach ($answers as $organization)
                {   
                    $objVideo = get_post( get_post_meta($organization->ID, "ftc_video_fk", true) );
                    $objStaff = get_post( get_post_meta($organization->ID, "org_staff_fk", true) );
                    $status = get_field("quiz_results", $organization->ID);
                    
                    ?>
                    <tr data-pid="<?php echo $organization->ID; ?>">
                        <td><?php echo $sno++; ?></td>
                        <td><?php echo $objVideo->post_title ?></td>
                        <td><?php echo $objStaff->post_title ?></td>
                        <td>
                            <?php echo $status?>
                        </td>
                    </tr>
                    <?php
                }
            }
            ?>
        </tbody>
    </table>
    <script>
        jQuery(document).ready(function(){
            var table = jQuery('#tbl_announcements').DataTable();
        });
    </script>
    <?php
    


}