<?php
//$link = add_query_arg();
?>
<a href="<?php echo get_permalink(); ?>">Sign Up</a>