<?php
/* User role */
/*
add_action('init', 'fs_wp_role');

function fs_wp_role() {
    
    if ( get_option( 'service_provider_version' ) != 1 ) {
        add_role('service_provider', __(
           'Service Provider'),
           array(
               'read'            => true,
               'level_100'        => true,
               'create_posts'   => false,
               'edit_posts'     => false,
               'delete_posts'   => false,
               //'edit_dashboard' => true
               )
        );
        update_option( 'service_provider_version', 1 );
    }

	if ( get_option( 'org_user_version' ) != 1 ) {
        add_role('org_user', __(
           'Organization User'),
           array(
               'read'            => true,
               'level_100'        => true,
               'create_posts'   => false,
               'edit_posts'     => false,
               'delete_posts'   => false,
               //'edit_dashboard' => true
               )
        );
        update_option( 'org_user_version', 1 );
    }

}
*/