<?php
/**
 * How to Remove WordPress Logo from Login Page
 * https://www.wppagebuilders.com/remove-wordpress-logo-from-login-page/
 */
/* Remove WP logo from login page */
function custom_login_logo() {
    echo '<style type ="text/css">.login h1 a { visibility:hidden!important; } #backtoblog a {visibility:hidden!important;} </style>';
}
add_action('login_head', 'custom_login_logo');